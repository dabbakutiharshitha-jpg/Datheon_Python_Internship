import "./styles.css";

type Position = {
  id: string;
  ticker: string;
  company: string;
  sector: string;
  shares: number;
  buyPrice: number;
  currentPrice: number;
  dayChange: number;
  updated: string;
};

type State = {
  positions: Position[];
  search: string;
  sector: string;
  drawerOpen: boolean;
  editingId: string | null;
  authenticated: boolean;
  loginError: string;
};

const seedPositions: Position[] = [
  { id: "tsla", ticker: "TSLA", company: "Tesla, Inc.", sector: "Consumer", shares: 18, buyPrice: 211.45, currentPrice: 248.98, dayChange: 2.84, updated: "2m ago" },
  { id: "nvda", ticker: "NVDA", company: "NVIDIA Corporation", sector: "Technology", shares: 12, buyPrice: 726.16, currentPrice: 875.28, dayChange: 1.21, updated: "2m ago" },
  { id: "aapl", ticker: "AAPL", company: "Apple Inc.", sector: "Technology", shares: 24, buyPrice: 168.92, currentPrice: 189.84, dayChange: -0.38, updated: "3m ago" },
  { id: "msft", ticker: "MSFT", company: "Microsoft Corporation", sector: "Technology", shares: 10, buyPrice: 369.24, currentPrice: 415.72, dayChange: 0.76, updated: "3m ago" },
];

const app = document.querySelector<HTMLDivElement>("#app")!;
if (!app) throw new Error("App root not found");

function loadPositions(): Position[] {
  try {
    const saved = localStorage.getItem("portfolio-desk-positions");
    if (!saved) return seedPositions;
    const parsed: unknown = JSON.parse(saved);
    if (!Array.isArray(parsed)) return seedPositions;
    return parsed.filter((item): item is Position => {
      if (!item || typeof item !== "object") return false;
      const candidate = item as Partial<Position>;
      return typeof candidate.id === "string" && typeof candidate.ticker === "string" && typeof candidate.company === "string" && typeof candidate.sector === "string" && typeof candidate.shares === "number" && Number.isFinite(candidate.shares) && typeof candidate.buyPrice === "number" && Number.isFinite(candidate.buyPrice) && typeof candidate.currentPrice === "number" && Number.isFinite(candidate.currentPrice);
    });
  } catch {
    return seedPositions;
  }
}

const state: State = {
  positions: loadPositions(),
  search: "",
  sector: "All sectors",
  drawerOpen: false,
  editingId: null,
  authenticated: localStorage.getItem("portfolio-desk-auth") === "true",
  loginError: "",
};

const money = (value: number, digits = 2) => new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: digits,
  maximumFractionDigits: digits,
}).format(value);

const compactMoney = (value: number) => {
  if (Math.abs(value) >= 1000000) return `$${(value / 1000000).toFixed(1)}m`;
  if (Math.abs(value) >= 1000) return `$${(value / 1000).toFixed(1)}k`;
  return money(value, 0);
};

const percent = (value: number) => `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
const escapeHtml = (value: string) => value.replace(/[&<>'"]/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;",
}[character] ?? character));

function calc(position: Position) {
  const invested = position.shares * position.buyPrice;
  const marketValue = position.shares * position.currentPrice;
  const gain = marketValue - invested;
  return { invested, marketValue, gain, gainPercent: invested ? (gain / invested) * 100 : 0 };
}

function save() {
  localStorage.setItem("portfolio-desk-positions", JSON.stringify(state.positions));
}

function icon(name: string, size = 18) {
  const paths: Record<string, string> = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    chart: '<path d="M4 19V5"/><path d="M4 19h17"/><path d="m7 15 4-4 3 2 5-7"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
    settings: '<path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/><path d="m19.4 15 .1.1a2 2 0 1 1-2.8 2.8l-.1-.1a2 2 0 0 0-3.4 1.4v.3a2 2 0 1 1-4 0v-.2A2 2 0 0 0 5.8 18l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a2 2 0 0 0-1.4-3.4h-.2a2 2 0 1 1 0-4h.2A2 2 0 0 0 3 4.4l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a2 2 0 0 0 3.4-1.4V0h4v.2A2 2 0 0 0 16.6 2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a2 2 0 0 0 1.4 3.4h.2a2 2 0 1 1 0 4h-.2a2 2 0 0 0-1.4 2.8Z"/>',
    download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    chevron: '<path d="m6 9 6 6 6-6"/>',
    edit: '<path d="m4 16-.8 4.8L8 20l11.5-11.5a2.8 2.8 0 0 0-4-4L4 16Z"/><path d="m14 6 4 4"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    trend: '<path d="m4 16 5-5 4 3 7-8"/><path d="M15 6h5v5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    pulse: '<path d="M3 12h4l2-7 4 14 2-7h6"/>',
  };
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] ?? paths.grid}</svg>`;
}

function getFilteredPositions() {
  const query = state.search.toLowerCase().trim();
  return state.positions.filter((position) => {
    const matchesQuery = !query || `${position.ticker} ${position.company} ${position.sector}`.toLowerCase().includes(query);
    const matchesSector = state.sector === "All sectors" || position.sector === state.sector;
    return matchesQuery && matchesSector;
  });
}

function positionInitials(position: Position) {
  return position.ticker.slice(0, 2);
}

function render() {
  if (!state.authenticated) {
    renderLogin();
    return;
  }
  const totals = state.positions.reduce((acc, position) => {
    const item = calc(position);
    acc.invested += item.invested;
    acc.marketValue += item.marketValue;
    acc.gain += item.gain;
    return acc;
  }, { invested: 0, marketValue: 0, gain: 0 });
  const totalGainPercent = totals.invested ? (totals.gain / totals.invested) * 100 : 0;
  const filtered = getFilteredPositions();
  const sectors = Array.from(new Set(state.positions.map((position) => position.sector)));
  const topPosition = [...state.positions].sort((a, b) => calc(b).marketValue - calc(a).marketValue)[0];
  const allocationColors = ["#56e0bb", "#8ba7ff", "#f7b267", "#ec8ba2", "#ad8bff"];
  const editingPosition = state.editingId ? state.positions.find((position) => position.id === state.editingId) : undefined;
  const formSectors = ["Technology", "Consumer", "Healthcare", "Financials", "Energy", "Industrials", "Other"];
  const sectorOptions = formSectors.map((sector) => `<option ${editingPosition?.sector === sector || (!editingPosition && sector === "Technology") ? "selected" : ""}>${sector}</option>`).join("");
  const donutStops = state.positions.length ? state.positions.reduce<{ stops: string[]; cursor: number }>((acc, position, index) => {
    const slice = totals.marketValue ? (calc(position).marketValue / totals.marketValue) * 100 : 0;
    acc.stops.push(`${allocationColors[index % allocationColors.length]} ${acc.cursor.toFixed(2)}% ${(acc.cursor + slice).toFixed(2)}%`);
    acc.cursor += slice;
    return acc;
  }, { stops: [], cursor: 0 }).stops.join(", ") : "#24313e 0 100%";
  const now = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(new Date());

  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand-lockup">
          <div class="brand-mark">${icon("trend", 20)}</div>
          <div class="brand-copy"><span>Portfolio</span><strong>DESK</strong></div>
        </div>
        <div class="workspace-switcher">
          <div class="workspace-avatar">HD</div>
          <div class="workspace-copy"><span>Harshitha's workspace</span><strong>Personal portfolio</strong></div>
          ${icon("chevron", 15)}
        </div>
        <div class="nav-group">
          <span class="nav-label">Workspace</span>
          <button class="nav-item active" data-scroll="overview">${icon("grid")}<span>Overview</span><span class="nav-hotkey">1</span></button>
          <button class="nav-item" data-scroll="holdings">${icon("chart")}<span>Holdings</span><span class="nav-count">${state.positions.length}</span></button>
          <button class="nav-item" data-scroll="activity">${icon("list")}<span>Transactions</span></button>
        </div>
        <div class="nav-group nav-group-bottom">
          <span class="nav-label">Your account</span>
          <button class="nav-item muted" data-action="settings">${icon("settings")}<span>Preferences</span></button>
        </div>
        <div class="sidebar-footer">
          <span class="status-orb"></span>
          <div><strong>Workspace live</strong><span>Saved locally</span></div>
          <button class="tiny-button" data-action="refresh" title="Refresh snapshot">${icon("pulse", 15)}</button>
        </div>
      </aside>

      <main class="main-content" id="overview">
        <header class="topbar">
          <div class="breadcrumbs"><span>Workspace</span><b>/</b><strong>Portfolio</strong></div>
          <div class="topbar-actions"><span class="market-status"><i></i>Market closed</span><button class="topbar-icon" aria-label="Toggle view" data-action="theme">${icon("sun", 17)}</button><button class="profile-chip profile-button" aria-label="Sign out" data-action="logout">HD</button></div>
        </header>

        <div class="page-content">
          <section class="hero-block">
            <div class="hero-copy">
              <div class="eyebrow"><span class="eyebrow-line"></span>PERSONAL PORTFOLIO / ${now.toUpperCase()}</div>
              <h1>Your money,<br /><em>in perspective.</em></h1>
              <p>One calm view of what you own, what it is worth, and how it is moving.</p>
            </div>
            <div class="hero-note">
              <div class="note-label">TODAY'S NOTE</div>
              <p>“The goal isn't to predict the market.<br />It's to know your position.”</p>
              <div class="note-rule"></div>
              <span>Portfolio Desk / 01</span>
            </div>
          </section>

          <div class="section-toolbar">
            <div class="section-heading"><span class="live-pip"></span><div><span class="overline">LIVE PORTFOLIO</span><strong>Overview</strong></div></div>
            <div class="toolbar-actions"><span class="snapshot-time">Snapshot updated just now</span><button class="button button-secondary" data-action="export">${icon("download", 16)}Export CSV</button><button class="button button-primary" data-action="add">${icon("plus", 16)}Add position</button></div>
          </div>

          <section class="metric-grid" aria-label="Portfolio totals">
            <article class="metric-card metric-card-featured"><div class="metric-top"><span class="overline">TOTAL VALUE</span><span class="metric-glyph">${icon("trend", 17)}</span></div><strong class="metric-value">${compactMoney(totals.marketValue)}</strong><div class="metric-foot"><span class="positive">${percent(totalGainPercent)}</span><span>all time</span></div><div class="mini-sparkline"><span style="height: 30%"></span><span style="height: 48%"></span><span style="height: 38%"></span><span style="height: 55%"></span><span style="height: 50%"></span><span style="height: 68%"></span><span style="height: 60%"></span><span style="height: 78%"></span><span style="height: 72%"></span><span style="height: 95%"></span></div></article>
            <article class="metric-card"><div class="metric-top"><span class="overline">INVESTED CAPITAL</span><span class="metric-dot dot-lilac"></span></div><strong class="metric-value">${compactMoney(totals.invested)}</strong><div class="metric-foot"><span class="neutral">${state.positions.length} holdings</span><span>across ${sectors.length || 0} sectors</span></div></article>
            <article class="metric-card"><div class="metric-top"><span class="overline">TOTAL RETURN</span><span class="metric-dot dot-peach"></span></div><strong class="metric-value ${totals.gain >= 0 ? "positive" : "negative"}">${totals.gain >= 0 ? "+" : "−"}${money(Math.abs(totals.gain), 0)}</strong><div class="metric-foot"><span class="positive">${percent(totalGainPercent)}</span><span>since first buy</span></div></article>
            <article class="metric-card"><div class="metric-top"><span class="overline">TOP POSITION</span><span class="metric-dot dot-blue"></span></div><strong class="metric-value">${topPosition ? topPosition.ticker : "—"}</strong><div class="metric-foot"><span class="neutral">${topPosition ? percent((calc(topPosition).marketValue / (totals.marketValue || 1)) * 100) : "0%"}</span><span>of portfolio</span></div></article>
          </section>

          <div class="content-grid">
            <section class="panel holdings-panel" id="holdings">
              <div class="panel-header">
                <div><span class="overline">YOUR POSITIONS</span><h2>Holdings <span class="count-pill">${state.positions.length}</span></h2></div>
                <div class="panel-actions"><label class="search-box">${icon("search", 16)}<input id="search-input" value="${escapeHtml(state.search)}" placeholder="Search holdings" aria-label="Search holdings" /></label><label class="select-box"><select id="sector-filter" aria-label="Filter by sector"><option>All sectors</option>${sectors.map((sector) => `<option ${state.sector === sector ? "selected" : ""}>${escapeHtml(sector)}</option>`).join("")}</select>${icon("chevron", 14)}</label></div>
              </div>
              <div class="table-wrap">
                ${filtered.length ? `<table><thead><tr><th>ASSET</th><th>SHARES</th><th>AVG. BUY</th><th>MARKET PRICE</th><th>MARKET VALUE</th><th>RETURN</th><th></th></tr></thead><tbody>${filtered.map((position) => {
                  const item = calc(position);
                  return `<tr><td><div class="asset-cell"><div class="asset-logo logo-${position.ticker.toLowerCase()}">${positionInitials(position)}</div><div><strong>${position.ticker}</strong><span>${escapeHtml(position.company)}</span></div></div></td><td><span class="cell-number">${position.shares}</span></td><td>${money(position.buyPrice)}</td><td><div class="market-price">${money(position.currentPrice)}<span class="day-move ${position.dayChange >= 0 ? "positive" : "negative"}">${position.dayChange >= 0 ? "+" : ""}${position.dayChange.toFixed(2)}%</span></div></td><td><strong>${money(item.marketValue, 0)}</strong></td><td><div class="return-cell"><strong class="${item.gain >= 0 ? "positive" : "negative"}">${item.gain >= 0 ? "+" : "−"}${money(Math.abs(item.gain), 0)}</strong><span class="${item.gain >= 0 ? "positive" : "negative"}">${percent(item.gainPercent)}</span></div></td><td><div class="row-actions"><button class="row-action" data-action="edit" data-id="${position.id}" aria-label="Edit ${position.ticker}">${icon("edit", 15)}</button><button class="row-action danger" data-action="delete" data-id="${position.id}" aria-label="Delete ${position.ticker}">${icon("trash", 15)}</button></div></td></tr>`;
                }).join("")}</tbody></table>` : `<div class="empty-state"><div class="empty-icon">${icon("chart", 24)}</div><h3>No positions found</h3><p>Try a different search or add your first holding to start tracking performance.</p><button class="button button-primary" data-action="add">${icon("plus", 16)}Add your first position</button></div>`}
              </div>
              <div class="table-footer"><span>Showing ${filtered.length} of ${state.positions.length} positions</span><span class="table-sync">${icon("clock", 13)} Sample prices • edit any row to update</span></div>
            </section>

            <section class="panel allocation-panel">
              <div class="panel-header"><div><span class="overline">PORTFOLIO MIX</span><h2>Allocation</h2></div><button class="more-button" data-action="allocation-info">•••</button></div>
              <div class="donut-wrap"><div class="donut" style="background: conic-gradient(${donutStops})"><div class="donut-center"><span>PORTFOLIO</span><strong>${compactMoney(totals.marketValue)}</strong></div></div></div>
              <div class="allocation-list">${state.positions.length ? state.positions.map((position, index) => { const share = totals.marketValue ? (calc(position).marketValue / totals.marketValue) * 100 : 0; return `<div class="allocation-row"><div class="legend-name"><i style="background:${allocationColors[index % allocationColors.length]}"></i><strong>${position.ticker}</strong><span>${escapeHtml(position.sector)}</span></div><b>${share.toFixed(1)}%</b></div>`; }).join("") : `<div class="muted-copy">Add a position to see your allocation mix.</div>`}</div>
              <div class="allocation-footer"><span>Concentration</span><strong>${topPosition && totals.marketValue ? ((calc(topPosition).marketValue / totals.marketValue) * 100).toFixed(0) : 0}% in ${topPosition?.ticker ?? "—"}</strong></div>
            </section>
          </div>

          <section class="insight-strip"><div class="insight-mark">${icon("pulse", 20)}</div><div><span class="overline">A LITTLE CONTEXT</span><p>${topPosition ? `<strong>${topPosition.ticker}</strong> is your largest position at ${money(calc(topPosition).marketValue, 0)}, making up ${((calc(topPosition).marketValue / (totals.marketValue || 1)) * 100).toFixed(0)}% of your total.` : "Your portfolio is ready for its first position."}</p></div><span class="insight-date">${now}</span></section>

          <section class="panel activity-panel" id="activity"><div class="panel-header"><div><span class="overline">ACTIVITY LOG</span><h2>Recent transactions</h2></div><button class="text-button" data-action="export">Download summary ${icon("arrow", 15)}</button></div><div class="activity-list">${state.positions.slice(0, 4).map((position) => `<div class="activity-row"><div class="activity-icon">${icon("plus", 16)}</div><div class="activity-description"><strong>Added ${position.shares} shares of ${position.ticker}</strong><span>Buy price ${money(position.buyPrice)} · ${position.company}</span></div><span class="activity-value">${money(position.shares * position.buyPrice, 0)}</span><span class="activity-time">${position.updated}</span></div>`).join("") || `<div class="empty-activity">No transactions yet. Add your first position to create an activity log.</div>`}</div></section>
          <footer class="page-footer"><span>Portfolio Desk <b>·</b> Private by default</span><span>Data stored locally in this browser</span></footer>
        </div>
      </main>

      ${state.drawerOpen ? `<div class="drawer-overlay" data-action="close-drawer"><aside class="drawer" data-drawer="true" aria-label="Position editor"><div class="drawer-header"><div><span class="overline">${state.editingId ? "EDIT POSITION" : "NEW POSITION"}</span><h2>${state.editingId ? "Update holding" : "Add a holding"}</h2></div><button class="close-button" data-action="close-drawer" aria-label="Close">${icon("close", 18)}</button></div><p class="drawer-intro">Keep the details simple. You can update the market price whenever you want a fresh snapshot.</p><form id="position-form"><label class="form-field"><span>Ticker symbol</span><input name="ticker" required maxlength="6" placeholder="e.g. AMZN" value="${editingPosition?.ticker ? escapeHtml(editingPosition.ticker) : ""}" /></label><label class="form-field"><span>Company name</span><input name="company" required placeholder="e.g. Amazon.com, Inc." value="${editingPosition?.company ? escapeHtml(editingPosition.company) : ""}" /></label><div class="form-row"><label class="form-field"><span>Shares</span><input name="shares" type="number" min="0.01" step="0.01" required placeholder="0" value="${editingPosition?.shares ?? ""}" /></label><label class="form-field"><span>Sector</span><select name="sector">${sectorOptions}</select></label></div><div class="form-row"><label class="form-field"><span>Average buy price</span><div class="input-prefix"><span>$</span><input name="buyPrice" type="number" min="0.01" step="0.01" required placeholder="0.00" value="${editingPosition?.buyPrice ?? ""}" /></div></label><label class="form-field"><span>Current price</span><div class="input-prefix"><span>$</span><input name="currentPrice" type="number" min="0.01" step="0.01" required placeholder="0.00" value="${editingPosition?.currentPrice ?? ""}" /></div></label></div><div class="form-note">${icon("pulse", 15)} Prices are sample snapshots. Update current price to keep returns current.</div><div class="drawer-actions"><button type="button" class="button button-secondary" data-action="close-drawer">Cancel</button><button type="submit" class="button button-primary">${state.editingId ? "Save changes" : "Add position"}</button></div></form></aside></div>` : ""}
      <div class="toast" id="toast" role="status" aria-live="polite"></div>
    </div>
  `;

  bindEvents();
}

function bindEvents() {
  document.querySelector<HTMLInputElement>("#search-input")?.addEventListener("input", (event) => {
    state.search = (event.target as HTMLInputElement).value;
    render();
    const input = document.querySelector<HTMLInputElement>("#search-input");
    input?.focus();
    if (input) input.setSelectionRange(state.search.length, state.search.length);
  });
  document.querySelector<HTMLSelectElement>("#sector-filter")?.addEventListener("change", (event) => {
    state.sector = (event.target as HTMLSelectElement).value;
    render();
  });
  document.querySelector<HTMLFormElement>("#position-form")?.addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget as HTMLFormElement;
    const data = new FormData(form);
    const ticker = String(data.get("ticker") ?? "").toUpperCase().trim();
    const company = String(data.get("company") ?? "").trim();
    const shares = Number(data.get("shares"));
    const buyPrice = Number(data.get("buyPrice"));
    const currentPrice = Number(data.get("currentPrice"));
    const sector = String(data.get("sector") ?? "Other");
    if (!ticker || !company || !shares || !buyPrice || !currentPrice) return;
    const existing = state.editingId ? state.positions.find((position) => position.id === state.editingId) : undefined;
    const updated: Position = { id: existing?.id ?? `${ticker.toLowerCase()}-${Date.now()}`, ticker, company, sector, shares, buyPrice, currentPrice, dayChange: existing?.dayChange ?? 0, updated: "just now" };
    state.positions = existing ? state.positions.map((position) => position.id === existing.id ? updated : position) : [updated, ...state.positions];
    save();
    state.drawerOpen = false;
    state.editingId = null;
    render();
    showToast(existing ? `${ticker} updated` : `${ticker} added to your portfolio`);
  });

  app.querySelectorAll<HTMLElement>("[data-action]").forEach((element) => element.addEventListener("click", (event) => {
    const action = element.dataset.action;
    if (element.closest("[data-drawer]") && action === "close-drawer") { event.stopPropagation(); }
    if (action === "add") { state.drawerOpen = true; state.editingId = null; render(); }
    if (action === "edit") { state.drawerOpen = true; state.editingId = element.dataset.id ?? null; render(); }
    if (action === "close-drawer") { state.drawerOpen = false; state.editingId = null; render(); }
    if (action === "delete") {
      const id = element.dataset.id;
      const position = state.positions.find((item) => item.id === id);
      if (id && position) { state.positions = state.positions.filter((item) => item.id !== id); save(); render(); showToast(`${position.ticker} removed from your portfolio`); }
    }
    if (action === "export") exportCsv();
    if (action === "refresh") { render(); showToast("Portfolio snapshot refreshed"); }
    if (action === "settings") showToast("Preferences are coming soon");
    if (action === "allocation-info") showToast("Allocation is based on current market value");
    if (action === "theme") document.body.classList.toggle("soft-mode");
    if (action === "logout") { state.authenticated = false; state.loginError = ""; localStorage.removeItem("portfolio-desk-auth"); render(); }
  }));
  app.querySelectorAll<HTMLElement>("[data-scroll]").forEach((element) => element.addEventListener("click", () => document.getElementById(element.dataset.scroll ?? "overview")?.scrollIntoView({ behavior: "smooth", block: "start" })));
}

function renderLogin() {
  app.innerHTML = `
    <main class="login-shell">
      <section class="login-visual">
        <div class="login-visual-top"><div class="brand-lockup login-brand"><div class="brand-mark">${icon("trend", 20)}</div><div class="brand-copy"><span>Portfolio</span><strong>DESK</strong></div></div><span class="login-edition">PRIVATE WORKSPACE / 01</span></div>
        <div class="login-visual-copy"><div class="eyebrow"><span class="eyebrow-line"></span>YOUR FINANCIAL VIEW</div><h1>Clarity for<br /><em>every position.</em></h1><p>A considered place to track what you own, how it is moving, and where your attention belongs next.</p></div>
        <div class="login-preview"><div class="preview-top"><span>PORTFOLIO VALUE</span><span class="preview-live"><i></i>MARKET SNAPSHOT</span></div><strong>$25,842<span>.68</span></strong><div class="preview-change">+12.46% <span>all time</span></div><div class="preview-chart"><span style="height: 25%"></span><span style="height: 41%"></span><span style="height: 33%"></span><span style="height: 56%"></span><span style="height: 48%"></span><span style="height: 64%"></span><span style="height: 59%"></span><span style="height: 81%"></span><span style="height: 74%"></span><span style="height: 96%"></span></div><div class="preview-labels"><span>JAN</span><span>APR</span><span>JUL</span><span>NOW</span></div></div>
        <div class="login-visual-footer"><span>“Know your position.”</span><span>PORTFOLIO DESK / PRIVATE BY DEFAULT</span></div>
      </section>
      <section class="login-panel">
        <div class="login-panel-inner">
          <div class="mobile-login-brand login-brand"><div class="brand-mark">${icon("trend", 20)}</div><div class="brand-copy"><span>Portfolio</span><strong>DESK</strong></div></div>
          <div class="login-heading"><span class="overline">WELCOME BACK</span><h2>Return to your<br /><em>perspective.</em></h2><p>Sign in to continue to your personal portfolio workspace.</p></div>
          <form class="login-form" id="login-form"><label class="form-field"><span>Email address</span><input type="email" name="email" autocomplete="email" placeholder="you@example.com" required /></label><label class="form-field"><div class="password-label"><span>Password</span><button type="button" class="forgot-button" data-action="forgot">Forgot password?</button></div><div class="password-input"><input type="password" name="password" autocomplete="current-password" placeholder="Enter your password" required minlength="4" /><button type="button" class="password-toggle" data-action="toggle-password" aria-label="Show password">Show</button></div></label>${state.loginError ? `<p class="login-error">${escapeHtml(state.loginError)}</p>` : ""}<label class="remember-row"><input type="checkbox" name="remember" checked /><span>Keep me signed in on this device</span></label><button class="login-submit" type="submit">Sign in <span>${icon("arrow", 16)}</span></button></form>
          <button class="demo-login" data-action="demo-login"><span>New here?</span> Use demo access <b>→</b></button>
          <div class="login-divider"><span>SECURE LOCAL WORKSPACE</span></div><p class="login-footnote">Your portfolio data stays in this browser. This demo login does not send credentials anywhere.</p>
        </div>
      </section>
    </main>
  `;
  app.querySelector<HTMLFormElement>("#login-form")?.addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget as HTMLFormElement;
    const data = new FormData(form);
    const email = String(data.get("email") ?? "").trim();
    const password = String(data.get("password") ?? "").trim();
    if (!email || !password) { state.loginError = "Enter your email and password to continue."; render(); return; }
    state.authenticated = true;
    state.loginError = "";
    if (data.get("remember")) localStorage.setItem("portfolio-desk-auth", "true");
    render();
  });
  app.querySelectorAll<HTMLElement>("[data-action]").forEach((element) => element.addEventListener("click", () => {
    const action = element.dataset.action;
    if (action === "demo-login") { state.authenticated = true; state.loginError = ""; localStorage.setItem("portfolio-desk-auth", "true"); render(); }
    if (action === "forgot") { state.loginError = "This demo uses local access. Try the demo button below."; render(); }
    if (action === "toggle-password") {
      const input = app.querySelector<HTMLInputElement>('input[name="password"]');
      if (input) { input.type = input.type === "password" ? "text" : "password"; element.textContent = input.type === "password" ? "Show" : "Hide"; }
    }
  }));
}

function exportCsv() {
  const headers = ["Ticker", "Company", "Sector", "Shares", "Average Buy Price", "Current Price", "Invested Capital", "Market Value", "Gain/Loss", "Gain/Loss %"];
  const rows = state.positions.map((position) => { const item = calc(position); return [position.ticker, position.company, position.sector, position.shares, position.buyPrice.toFixed(2), position.currentPrice.toFixed(2), item.invested.toFixed(2), item.marketValue.toFixed(2), item.gain.toFixed(2), item.gainPercent.toFixed(2)]; });
  const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const objectUrl = URL.createObjectURL(blob);
  link.href = objectUrl;
  link.download = `portfolio_summary_${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  showToast("CSV summary downloaded");
}

let toastTimer: number | undefined;
function showToast(message: string) {
  const toast = document.querySelector<HTMLDivElement>("#toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2600);
}

render();
